var numberOfSounds = document.querySelectorAll(".sound").length;

for (var i = 0; i < numberOfSounds; i++){

    document.querySelectorAll("button")[i].addEventListener("click", function () {

        var audio = new Audio('sounds/button-2.mp3');
        audio.play();
        
    });
    
}